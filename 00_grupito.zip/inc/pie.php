<footer class="container">
  <p><strong>©CrissDg</strong> -2020-</p>
</footer>
<script src="js/jquery-3.js"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="js/bootstrap.js" ></script>

</body>
</html>