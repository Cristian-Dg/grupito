<?php
	define ("HOST","localhost");
	define ("DBNAME","grupito");
	define ("USER","root");
	define ("PASS","");
?>