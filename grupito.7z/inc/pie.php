<footer class="container">
  <p><strong>©CrissDg</strong> -<i>2020</i>-</p>
</footer>
<script src="js/jquery-3.js"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="js/bootstrap.js" ></script>
	  <script src="https://kit.fontawesome.com/3f57268255.js" crossorigin="anonymous"></script>
</body>
</html>